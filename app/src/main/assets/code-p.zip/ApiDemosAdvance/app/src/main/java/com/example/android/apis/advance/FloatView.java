package com.example.android.apis.advance;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

import com.example.android.apis.ApiDemosApplication;
import com.example.android.apis.R;

public class FloatView extends View {
    public static final String EXTRA_ACTIVITY = "extra_activity";
    private float mTouchStartX;
    private float mTouchStartY;
    private float x;
    private float y;
    private long mDownTime;
    private boolean mIsMove;

    private WindowManager wm=(WindowManager)getContext().getApplicationContext().getSystemService(Context.WINDOW_SERVICE);
    private WindowManager.LayoutParams wmParams = ((ApiDemosApplication)getContext().getApplicationContext()).getMywmParams();

    private FloatView(Context context) {
        super(context);
    }

    public static FloatView showView(Context context){
        FloatView floatView=new FloatView(context.getApplicationContext());
        floatView.setBackgroundResource(R.drawable.red);
        WindowManager wm=(WindowManager)context.getApplicationContext().getSystemService(Context.WINDOW_SERVICE);
        WindowManager.LayoutParams param = ((ApiDemosApplication)context.getApplicationContext()).getMywmParams();

        param.type=WindowManager.LayoutParams.TYPE_SYSTEM_ALERT;
        param.format=1;
        param.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        param.flags = param.flags | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH;
        param.flags = param.flags | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;

        param.alpha = 1.0f;

        param.gravity= Gravity.LEFT|Gravity.TOP;
        param.width=140;
        param.height=140;

        wm.addView(floatView, param);
        return floatView;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        x = event.getRawX();
        y = event.getRawY()-25;
        Log.i("currP", "currX"+x+"====currY"+y);
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                mIsMove = false;
                mTouchStartX =  event.getX();
                mTouchStartY =  event.getY();

                Log.i("startP", "startX"+mTouchStartX+"====startY"+mTouchStartY);

                break;
            case MotionEvent.ACTION_MOVE:
                mIsMove = true;
                updateViewPosition();
                break;

            case MotionEvent.ACTION_UP:
                if (!mIsMove) {
                    performClick();
                }
                mTouchStartX=mTouchStartY=0;
                break;
        }
        return true;
    }

    private void updateViewPosition(){
        wmParams.x=(int)( x-mTouchStartX);
        wmParams.y=(int) (y-mTouchStartY);
        wm.updateViewLayout(this, wmParams);
    }

    public void removeView() {
        wm.removeView(this);
    }

    @Override
    public boolean performClick() {
        String currentActivityName = ((ApiDemosApplication)getContext().getApplicationContext()).getCurrentActivityName();
        if (!"com.example.android.apis.advance.AdvanceActivity".equals(currentActivityName)) {
            Intent intent = new Intent(getContext(), AdvanceActivity.class);
            intent.putExtra(EXTRA_ACTIVITY, currentActivityName);
            getContext().startActivity(intent);
        }
        return super.performClick();
    }
}
