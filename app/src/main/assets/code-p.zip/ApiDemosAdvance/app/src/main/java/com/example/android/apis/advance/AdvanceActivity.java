package com.example.android.apis.advance;

import android.app.Activity;
import android.os.Bundle;

import com.example.android.apis.R;

public class AdvanceActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_advance);
    }
}
