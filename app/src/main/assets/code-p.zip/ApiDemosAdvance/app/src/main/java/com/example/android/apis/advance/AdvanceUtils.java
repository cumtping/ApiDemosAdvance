package com.example.android.apis.advance;

import android.content.Context;
import android.content.res.AssetManager;
import android.util.Log;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;

public class AdvanceUtils {
    private static final String TAG = AdvanceUtils.class.getSimpleName();

    public static boolean copyAssetToSdcard(Context context, String assetName, String sdcardPath) {
        String filePath = sdcardPath + assetName;
        // Create folder if needed.
        File dirFile = new File(sdcardPath);
        if (!dirFile.exists()) {
            dirFile.mkdir();
        }
        File file = new File(filePath);
        if (file.exists()) {
            // File exists, return.
            return true;
        }

        AssetManager asset = context.getAssets();
        FileOutputStream out = null;
        InputStream in=null;
        try {
            in = asset.open(assetName);
            out = new FileOutputStream(filePath);
            byte[] buffer = new byte[1024];
            int byteCount=0;
            while((byteCount=in.read(buffer))!=-1){
                out.write(buffer, 0, byteCount);
            }
            out.flush();
            return true;
        } catch (IOException e) {
            Log.e(TAG, "Open file error", e);
        } finally{
            try {
                if (out != null) {
                    out.close();
                }
                if (in != null) {
                    in.close();
                }
                // AssetManager shouldn't be closed.
                // if (asset != null) {
                //     asset.close();
                // }
            } catch (IOException e) {
                Log.e(TAG, "Open file error2", e);
            }
        }
        return false;
    }

    /**
     * 含子目录的文件压缩
     *
     * @throws Exception
     */
    // 第一个参数就是需要解压的文件，第二个就是解压的目录
    public static boolean upZipFile(String zipFile, String folderPath) {
        ZipFile zfile = null;
        try {
            // 转码为GBK格式，支持中文
            zfile = new ZipFile(zipFile);
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        Enumeration zList = zfile.entries();
        ZipEntry ze = null;
        byte[] buf = new byte[1024];
        while (zList.hasMoreElements()) {
            try {
                ze = (ZipEntry) zList.nextElement();
            } catch (IllegalArgumentException e) {
                Log.e(TAG, "IllegalArgumentException", e);
            }
            // 列举的压缩文件里面的各个文件，判断是否为目录
            if (ze.isDirectory()) {
                String dirstr = folderPath + ze.getName();
                Log.i(TAG, "dirstr=" + dirstr);
                dirstr.trim();
                File f = new File(dirstr);
                f.mkdir();
                continue;
            }
            OutputStream os = null;
            FileOutputStream fos = null;
            // ze.getName()会返回 script/start.script这样的，是为了返回实体的File
            File realFile = getRealFileName(folderPath, ze.getName());
            try {
                fos = new FileOutputStream(realFile);
            } catch (FileNotFoundException e) {
                Log.e(TAG, e.getMessage());
                return false;
            }
            os = new BufferedOutputStream(fos);
            InputStream is = null;
            try {
                is = new BufferedInputStream(zfile.getInputStream(ze));
            } catch (IOException e) {
                Log.e(TAG, e.getMessage());
                return false;
            }
            int readLen = 0;
            // 进行一些内容复制操作
            try {
                while ((readLen = is.read(buf, 0, 1024)) != -1) {
                    os.write(buf, 0, readLen);
                }
            } catch (IOException e) {
                Log.e(TAG, e.getMessage());
                return false;
            }
            try {
                is.close();
                os.close();
            } catch (IOException e) {
                Log.e(TAG, e.getMessage());
                return false;
            }
        }
        try {
            zfile.close();
        } catch (IOException e) {
            Log.e(TAG, e.getMessage());
            return false;
        }
        return true;
    }

    /**
     * 给定根目录，返回一个相对路径所对应的实际文件名.
     *
     * @param baseDir
     *            指定根目录
     * @param absFileName
     *            相对路径名，来自于ZipEntry中的name
     * @return java.io.File 实际的文件
     */
    public static File getRealFileName(String baseDir, String absFileName) {
        Log.i(TAG, "baseDir=" + baseDir + "------absFileName="
                + absFileName);
        absFileName = absFileName.replace("\\", "/");
        Log.i(TAG, "absFileName=" + absFileName);
        String[] dirs = absFileName.split("/");
        Log.i(TAG, "dirs=" + dirs);
        File ret = new File(baseDir);
        String substr = null;
        if (dirs.length > 1) {
            for (int i = 0; i < dirs.length - 1; i++) {
                substr = dirs[i];
                ret = new File(ret, substr);
            }

            if (!ret.exists())
                ret.mkdirs();
            substr = dirs[dirs.length - 1];
            ret = new File(ret, substr);
            return ret;
        } else {
            ret = new File(ret, absFileName);
        }
        return ret;
    }

//    public static void unzip(String zipFile, String targetDir) {
//        int BUFFER = 4096;
//        String strEntry;
//
//        try {
//            BufferedOutputStream dest;
//            FileInputStream fis = new FileInputStream(zipFile);
//            ZipInputStream zis = new ZipInputStream(new BufferedInputStream(fis));
//            ZipEntry entry;
//
//            while ((entry = zis.getNextEntry()) != null) {
//                    Log.i(TAG,"entry="+ entry);
//                    int count;
//                    byte data[] = new byte[BUFFER];
//                    strEntry = entry.getName();
//
//                    File entryFile = new File(targetDir + strEntry);
//                    File entryDir = new File(entryFile.getParent());
//                    if (!entryDir.exists()) {
//                        entryDir.mkdirs();
//                    }
//
//                    FileOutputStream fos = new FileOutputStream(entryFile);
//                    dest = new BufferedOutputStream(fos, BUFFER);
//                    while ((count = zis.read(data, 0, BUFFER)) != -1) {
//                        dest.write(data, 0, count);
//                    }
//                    dest.flush();
//                    dest.close();
//            }
//            zis.close();
//        } catch (FileNotFoundException e) {
//            Log.e(TAG, "Unzip, file not found.", e);
//        } catch (IOException e) {
//            Log.e(TAG, "Unzip, IOException.", e);
//        } catch (IllegalArgumentException e) {
//            Log.e(TAG, "Unzip, IllegalArgumentException.", e);
//        }
//    }
}
