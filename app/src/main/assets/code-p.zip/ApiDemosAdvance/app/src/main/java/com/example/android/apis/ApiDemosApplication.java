/*
 * Copyright (c) 2018. Parrot Faurecia Automotive S.A.S. All rights reserved.
 */

package com.example.android.apis;

import com.example.android.apis.advance.AdvanceUtils;
import com.orhanobut.logger.Logger;

import android.app.Activity;
import android.app.Application;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.WindowManager;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * This is an example of a {@link Application} class.  This can
 * be used as a central repository for per-process information about your app;
 * however it is recommended to use singletons for that instead rather than merge
 * all of these globals from across your application into one place here.
 * 
 * In this case, we have not defined any specific work for this Application.
 * 
 * See samples/ApiDemos/tests/src/com.example.android.apis/ApiDemosApplicationTests for an example
 * of how to perform unit tests on an Application object.
 */
public class ApiDemosApplication extends Application {
    private static final String TAG = ApiDemosApplication.class.getSimpleName();
    private WindowManager.LayoutParams wmParams=new WindowManager.LayoutParams();
    private String mCurrentActivityName;
    private String mExternalStoragePath = Environment.getExternalStorageDirectory().getPath();

    @Override
    public void onCreate() {
        super.onCreate();
        //初始化日志打印工具类
        Logger.init("ApiDemos");
        registerActivityLifecycleCallbacks();
        copyAndUnzip();
    }

    public WindowManager.LayoutParams getMywmParams(){
        return wmParams;
    }

    public String getCurrentActivityName() {
        return mCurrentActivityName;
    }

    private void registerActivityLifecycleCallbacks() {
        this.registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
            @Override
            public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
                mCurrentActivityName = activity.getComponentName().getClassName();
            }

            @Override
            public void onActivityStarted(Activity activity) {

            }

            @Override
            public void onActivityResumed(Activity activity) {

            }

            @Override
            public void onActivityPaused(Activity activity) {

            }

            @Override
            public void onActivityStopped(Activity activity) {

            }

            @Override
            public void onActivitySaveInstanceState(Activity activity, Bundle outState) {

            }

            @Override
            public void onActivityDestroyed(Activity activity) {

            }
        });
    }

    public void copyAndUnzip() {
        String appSdcardPath = mExternalStoragePath + "/ApiDemos/";
        String codeZipName = "code.zip";
//        String codeFolderName = "code";

        boolean copyDone = AdvanceUtils.copyAssetToSdcard(this, codeZipName, appSdcardPath);
        if (copyDone) {
            AdvanceUtils.upZipFile(appSdcardPath + codeZipName, appSdcardPath);
        }
    }
}
